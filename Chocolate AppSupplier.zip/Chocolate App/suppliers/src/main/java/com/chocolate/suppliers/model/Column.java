package com.chocolate.suppliers.model;

public @interface Column {

    boolean unique();
}
