package com.chocolate.suppliers.model;

public @interface NotNull {

    String message();
}
