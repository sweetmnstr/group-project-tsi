package com.chocolate.suppliers.service;

import com.chocolate.suppliers.model.Supplier;

import java.util.List;
import java.util.Optional;

public class SupplierRepository {
    private Supplier supplier;

    public List<Supplier> findAll() {
        return List.of();
    }

    public Optional<Object> findById(Long id) {
        return Optional.empty();
    }

    public boolean existsBySupplierCode(String supplierCode) {
        return false;
    }

    public Supplier save(Supplier supplier) {
        this.supplier = supplier;
        return supplier;
    }

    public void deleteById(Long id) {
    }
}
