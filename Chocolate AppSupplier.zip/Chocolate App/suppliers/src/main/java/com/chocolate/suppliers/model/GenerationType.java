package com.chocolate.suppliers.model;

public class GenerationType {

    public static final Object IDENTITY = null;
}
