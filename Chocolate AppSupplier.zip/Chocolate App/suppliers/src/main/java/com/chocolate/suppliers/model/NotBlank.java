package com.chocolate.suppliers.model;

public @interface NotBlank {
    String message();
}
