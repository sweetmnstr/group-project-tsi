package com.chocolate.suppliers.model;

public @interface Id {

}
