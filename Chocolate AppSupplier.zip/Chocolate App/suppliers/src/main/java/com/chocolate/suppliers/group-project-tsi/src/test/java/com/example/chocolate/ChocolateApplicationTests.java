package com.example.chocolate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChocolateApplicationTests {

    @Test
    void contextLoads() {
    }

}
