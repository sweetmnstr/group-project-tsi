package com.chocolate.suppliers.service;

import com.chocolate.suppliers.model.Supplier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SupplierService {
    @Autowired
    private com.chocolate.suppliers.service.SupplierRepository repository;

    public List<Supplier> getAllSuppliers() { return repository.findAll(); }

    public Object getSupplierById(Long id) {
        return repository.findById(id).orElseThrow(() -> new IllegalArgumentException("Supplier not found"));
    }

    public Supplier addSupplier(Supplier supplier) {
        if (repository.existsBySupplierCode(supplier.getSupplierCode())) {
            throw new IllegalArgumentException("Supplier code must be unique");
        }
        return repository.save(supplier);
    }

    public Supplier updateSupplier(Long id, Supplier supplier) {
        Supplier existingSupplier = (Supplier) getSupplierById(id);
        if (!existingSupplier.getSupplierCode().equals(supplier.getSupplierCode()) &&
                repository.existsBySupplierCode(supplier.getSupplierCode())) {
            throw new IllegalArgumentException("Supplier code must be unique");
        }
        supplier.setId(id);
        return repository.save(supplier);
    }

    public void deleteSupplier(Long id) {
        repository.deleteById(id);
    }
}