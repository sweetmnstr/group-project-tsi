package com.chocolate.suppliers;

public @interface Valid {
}
