package com.chocolate.suppliers;

public interface JpaRepository<T1, T2> {

}
