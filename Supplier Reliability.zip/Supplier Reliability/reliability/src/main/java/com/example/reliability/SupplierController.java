package com.example.reliability;

import com.example.suppliertracker.model.Supplier;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/suppliers")
public class SupplierController {
    private final SupplierService service;

    public SupplierController(SupplierService service) {
        this.service = service;
    }

    @GetMapping
    public List<Supplier> getAllSuppliers() {
        return service.getAllSuppliers();
    }

    @PostMapping
    public Supplier addSupplier(@RequestBody Supplier supplier) {
        return service.addSupplier(supplier);
    }

    @GetMapping("/{id}/reliability-rate")
    public double getReliabilityRate(@PathVariable Long id) {
        Supplier supplier = service.getAllSuppliers().stream()
                .filter(s -> s.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Supplier not found!"));
        return service.calculateReliabilityRate(supplier);
    }
}