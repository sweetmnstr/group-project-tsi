package com.example.suppliertracker.repository;

public interface JpaRepository<T, T1> {
}
