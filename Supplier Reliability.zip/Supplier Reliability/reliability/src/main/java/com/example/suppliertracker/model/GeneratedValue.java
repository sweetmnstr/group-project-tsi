package com.example.suppliertracker.model;

public @interface GeneratedValue {

    String strategy();

}
