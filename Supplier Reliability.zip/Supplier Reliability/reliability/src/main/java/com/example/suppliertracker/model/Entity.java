package com.example.suppliertracker.model;

public @interface Entity {

}
