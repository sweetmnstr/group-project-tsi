package com.example.suppliertracker.repository;

import com.example.suppliertracker.model.Supplier;

import java.util.List;

public interface SupplierRepository extends com.example.suppliertracker.repository.JpaRepository<Supplier, Long> {
    List<com.example.suppliertracker.model.Supplier> findAll();
}