package com.example.reliability;

import com.example.suppliertracker.model.Supplier;
import com.example.suppliertracker.repository.SupplierRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SupplierService {
    private final SupplierRepository repository;

    public SupplierService(SupplierRepository repository) {
        this.repository = repository;
    }

    public List<Supplier> getAllSuppliers() {
        return repository.findAll();
    }

    public Supplier addSupplier(Supplier supplier) {
        return repository.save(supplier);
    }

    public double calculateReliabilityRate(Supplier supplier) {
        if (supplier.getTotalDeliveries() == 0) {
            return 0.0;
        }
        return (double) supplier.getOnTimeDeliveries() / supplier.getTotalDeliveries() * 100;
    }
}