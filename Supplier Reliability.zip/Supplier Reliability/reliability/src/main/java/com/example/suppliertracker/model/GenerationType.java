package com.example.suppliertracker.model;

public class GenerationType {

    public static final Object IDENTITY = "";
}
